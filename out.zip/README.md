# rect-dictionaries
Dictionaries support for the rect programming language
